#WAP to add all numbers from 1 to n
n = int(input("Enter a number: "))
sum = 0
for i in range(1, n+1):
    sum += i
print(f"The sum of numbers from 1 to {n} is: {sum}")